 * * * * * * * * * * 
 *       emu       * 
 * * * * * * * * * * 

 8086 assembler and 
 microprocessor emulator 

 study computer arhitecture 
 and assembly language 
 programming, 

 emulate hardware, 
 screen, memory and 
 input/output devices. 
