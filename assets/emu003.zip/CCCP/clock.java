


import java.util.*;
import java.awt.*;
import java.awt.event.*;

/**

clock  

version 3 for jdk1.1.3
10:21 AM April 24, 2014

@author Y.MARGOLIN +972.8.6528229

*/


public class clock extends Frame implements Runnable, WindowListener{

Thread m;

String s = "";

public static void main (String [] a) {

 clock c = new clock();

 c.setSize(300, 200);
 c.setVisible(true);

} /* end main */

public clock () {
 m = new Thread(this);
 m.start();
 addWindowListener(this);
} /* end contructor */

public void windowClosing(WindowEvent e) {
   System.exit(0);
}

public void windowDeactivated(WindowEvent e) {

}

public void windowActivated(WindowEvent e) {

}


public void windowDeiconified(WindowEvent e) {

}


public void windowIconified(WindowEvent e) {

}

public void windowClosed(WindowEvent e) {

}


public void windowOpened(WindowEvent e) {

}

public void run() {

 while(true) {

   try {
    m.sleep(1000);
    repaint();
   } catch(Exception e){}
 } /* loop */

} /* end run */


public void update(Graphics g) {
  paint(g);
}


public void paint(Graphics gx) {

 Image h;
 h = createImage(300, 200);
 Graphics g;
 g = h.getGraphics();

 g.drawString("This is experimental", 10, 50) ;
 g.drawString(" prototype version 3 ", 10, 80) ;
 g.drawString(" . . . ", 10, 120) ;

 Color c;

 c = g.getColor();

 g.setColor(this.getBackground());
 
 g.drawString(s, 10, 150); /* clear */

 g.setColor(c);

 s = (new Date()).toString();

 g.drawString(s, 10, 150);

 

 gx.drawImage(h, 0, 0, this);
}

} /* end class */

