/**

binary file reader

reference:
java api documentation

*/

import java.io.*;

public class binreader {

public static 
void main(String a[]) {

System.out.println("hallelujah my name is binreader");

try {
FileInputStream f = new FileInputStream(a[0]);

int c = 0;
while(true) {
 int i = f.read();
 if (i == -1) {
    break;
 }
 System.out.println("byte " + c + ": " + i);
 c++;
} /* end while */

f.close();

} catch (Exception e) {

}

System.out.println("amen");

} /* end main */

} /* end class */
